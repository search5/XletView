
import java.awt.event.*;
import com.momo.automata.*;

public class AutomataTest implements CharacterListener
{
    private String      mainText = "";
    private int         cursorPos = 0;
    private int         mode;
    private Automata    am;

    public void characterEvent(int eventType, char c)
    {
        switch (eventType) {
            case Automata.EVENT_UPDATE:
                display();
                break;

            case Automata.EVENT_DELETE:
                if (mainText.length() > 0) {
                    if (mainText.length() == cursorPos)
                        cursorPos--;
                    mainText = mainText.substring(0, mainText.length()-1);
                }
                break;

            case Automata.EVENT_PUT:
                if (cursorPos == mainText.length())
                    mainText += c;
                else
                    mainText = mainText.substring(0, mainText.length()-1) + c;
                break;

            case Automata.EVENT_NEXT:
                cursorPos++;
                break;

            case Automata.EVENT_KEYMAP:
                {
                    char[] keyMap = am.getCurrentKeyMap();
                    for (int i = 0; i < 4; ++i) {
                        for (int j = 0; j < 3; ++j) {
                            for(int k = 0; k < 3; ++k) {
                                System.out.print(keyMap[i*9 + j*3 + k]);
                            }
                            System.out.print(" ");
                        }
                        System.out.println();
                    }
                }
                break;
        }
    }

    public static String readLine()
    {  int ch;
        String r = "";
        boolean done = false;
        while (!done)
        {  try
            {  ch = System.in.read();
                if (ch < 0 || (char)ch == '\n')
                    done = true;
                else if ((char)ch != '\r') 
                    // weird--it used to do \r\n translation
                    r = r + (char) ch;
            }
            catch(java.io.IOException e)
            {  done = true;
            }
        }
        return r;
    }

    public static void main(String args[])
    {
        AutomataTest    cl = new AutomataTest();

        cl.am = com.momo.automata.AutomataManager.createInstance();
        cl.mode = Automata.NUMERIC_MODE;

        Automata am = cl.am;
        am.setCharacterListener(cl);
        HighlightListener hl = new TestHigh();
        am.setHighlightListener(hl);
        am.setCurrentMode(Automata.KOREAN_MODE);

        while (true) {
            String cmd = readLine();

            if (cmd.compareTo("x") == 0)
                break;
            if (cmd.compareTo("l") == 0) {
                if (cl.cursorPos > 0)
                    cl.cursorPos--;
                cl.display();
            } else if (cmd.compareTo("r") == 0){
                if (cl.cursorPos == cl.mainText.length()) {
                    cl.mainText += " ";
                }
                cl.cursorPos++;
                am.resetStatus(false);
            } else if (cmd.compareTo("b") == 0) {
                am.keyPressed(KeyConstant.KEY_DELETE);
            } else if (cmd.compareTo("1") == 0) {
                am.keyPressed(KeyEvent.VK_1);
            } else if (cmd.compareTo("2") == 0) {
                am.keyPressed(KeyEvent.VK_2);
            } else if (cmd.compareTo("3") == 0) {
                am.keyPressed(KeyEvent.VK_3);
            } else if (cmd.compareTo("4") == 0) {
                am.keyPressed(KeyEvent.VK_4);
            } else if (cmd.compareTo("5") == 0) {
                am.keyPressed(KeyEvent.VK_5);
            } else if (cmd.compareTo("6") == 0) {
                am.keyPressed(KeyEvent.VK_6);
            } else if (cmd.compareTo("7") == 0) {
                am.keyPressed(KeyEvent.VK_7);
            } else if (cmd.compareTo("8") == 0) {
                am.keyPressed(KeyEvent.VK_8);
            } else if (cmd.compareTo("9") == 0) {
                am.keyPressed(KeyEvent.VK_9);
            } else if (cmd.compareTo("0") == 0) {
                am.keyPressed(KeyEvent.VK_0);
            } else if (cmd.compareTo("*") == 0) {
                am.keyPressed(KeyConstant.KEY_STAR);
            } else if (cmd.compareTo("#") == 0) {
                am.keyPressed(KeyConstant.KEY_SHARP);
            } else if (cmd.compareTo("m") == 0) {
                switch (cl.mode) {
                    case Automata.KOREAN_MODE:
                        cl.mode = Automata.NUMERIC_MODE;
                        break;
                    case Automata.NUMERIC_MODE:
                        cl.mode = Automata.SYMBOL_MODE;
                        break;
                    case Automata.SYMBOL_MODE:
                        cl.mode = Automata.ENGLISH_SMALL_MODE;
                        break;
                    case Automata.ENGLISH_SMALL_MODE:
                    case Automata.ENGLISH_LARGE_MODE:
                        cl.mode = Automata.KOREAN_MODE;
                }
                am.setCurrentMode(cl.mode);
            }
        }
    }

    public void display()
    {
        System.out.println("|" + mainText + "|");
        for (int i = 0; i < cursorPos+1; ++i)
            System.out.print(" ");

        System.out.println("|");
        System.out.println( "Length: " + 
                            mainText.length() + 
                            "    CursorPos: " + 
                            cursorPos);
    }
}

class TestHigh implements HighlightListener {
    public void highlightEvent(int eventType, int button, int index, char c) {
        System.out.println("Highlight "+eventType+" "+button+" "+index+" "+c);
    }
}

